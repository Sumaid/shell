#ifndef EXECUTEINPUT_H_INCLUDED
#define EXECUTEINPUT_H_INCLUDED

int execute_input();
int execute_input1();
int pipeexecute_input();

#endif
