#ifndef PWD_H_INCLUDED
#define PWD_H_INCLUDED

void pwd();

#endif
