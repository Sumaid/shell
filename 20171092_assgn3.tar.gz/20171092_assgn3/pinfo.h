#ifndef PINFO_H_INCLUDED
#define PINFO_H_INCLUDED

void proc_info();
void pinfo();

#endif