#ifndef CLOCK_H_INCLUDED
#define CLOCK_H_INCLUDED

void self_clock();

#endif
