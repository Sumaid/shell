#ifndef USER_DEFINED_H_INCLUDED
#define USER_DEFINED_H_INCLUDED

void env_setter();
void env_unsetter();
void jobs();
void overkill();
void kjob();
void fg();
void bg();

#endif
