#ifndef READINPUT_H_INCLUDED
#define READINPUT_H_INCLUDED

void read_input();

#endif
