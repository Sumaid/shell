#ifndef PARSEINPUT_H_INCLUDED
#define PARSEINPUT_H_INCLUDED

void parse_input();

#endif
