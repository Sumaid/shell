#ifndef LS_H_INCLUDED
#define LS_H_INCLUDED

void regular_ls(char* path, int a);
void full_ls_file(char* file, int a, int max);
void full_ls(char* path, int a);
void ls();

#endif
