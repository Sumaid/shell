#ifndef ECHO_H_INCLUDED
#define ECHO_H_INCLUDED

void echo();

#endif
